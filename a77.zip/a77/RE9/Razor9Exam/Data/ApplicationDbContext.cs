﻿using Microsoft.EntityFrameworkCore;
using Razor9Exam.Model;

namespace Razor9Exam.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Category> Categoriesss { get; set; }
        public DbSet<Product> Productss { get; set; }

    }
}
