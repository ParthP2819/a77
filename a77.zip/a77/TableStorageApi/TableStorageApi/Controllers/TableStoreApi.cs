﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Azure.Documents;
using static System.Net.WebRequestMethods;

namespace TableStorageApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TableStoreApi : ControllerBase
    {
        public string connstr = "DefaultEndpointsProtocol=https;AccountName=parthstorageaccounts;AccountKey=oNkpucECE0bTMczvT+1YB/DdYFwcajcSt1uUASzz+mAaU17q4ZIBfL4x2zAg+GI35ectisKvWhZO+AStzFHKLQ==;EndpointSuffix=core.windows.net";
        //public string tableName = "TestTable";

        [HttpGet]
        [Route("GetData/")]
        public async Task GetEntityAsync(string tableName)
        {
            //var tableClient = await GetTableClient();
            //return await tableClient.GetEntityAsync;
        }

        [HttpPost]
        [Route("InsertData/")]
        public async Task InsertData(string tableName, string firstName, string lastName, string Email, string PhoneNumber)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connstr);
            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();
            CloudTable cloudTable = tableClient.GetTableReference(tableName);
            cloudTable.CreateIfNotExistsAsync().Wait();

            EntityClass myClass = new EntityClass(firstName, lastName)
            {
                Email = Email,
                PhoneNumber = PhoneNumber
            };
            await MergeUser(cloudTable, myClass);
        }

        public static async Task MergeUser(CloudTable cloudTable, EntityClass myClass)
        {
            TableOperation tblOpt = TableOperation.Insert(myClass);
            TableResult tblResult = await cloudTable.ExecuteAsync(tblOpt);
            EntityClass entity = tblResult.Result as EntityClass;
        }

        public class EntityClass : TableEntity
        {
            public EntityClass(string firstName, string lastName)
            {
                PartitionKey = firstName;
                RowKey = lastName;
            }
            public string Email { get; set; }
            public string PhoneNumber { get; set; }
        }
    }
}
